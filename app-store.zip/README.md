```text
https://github.com/servalabs/app-store/archive/refs/heads/main.zip
```
